import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 *  A Jeroo island containing two "castle"-style lakes.
 *
 *  @author Lindah Kotut
 *  @version 2017.09.05
 */
public class Castles extends Island
{
    //~ Fields ................................................................


    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Castles object.
     */
    public Castles()
    {
        super(14, 10);

        prepare();
    }

    //~ Methods ...............................................................

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        this.add(new Water(), 2, 3);
        this.add(new Water(), 3, 3);
        this.add(new Water(), 4, 3);
        this.add(new Water(), 4, 4);
        this.add(new Water(), 3, 4);
        this.add(new Water(), 2, 4);
        this.add(new Water(), 2, 5);
        this.add(new Water(), 3, 5);
        this.add(new Water(), 4, 5);
        this.add(new Water(), 7, 2);
        this.add(new Water(), 8, 3);
        this.add(new Water(), 9, 3);
        this.add(new Water(), 10, 3);
        this.add(new Water(), 11, 2);
        this.add(new Water(), 10, 4);
        this.add(new Water(), 9, 4);
        this.add(new Water(), 8, 4);
        this.add(new Water(), 8, 5);
        this.add(new Water(), 9, 5);
        this.add(new Water(), 10, 5);
        this.add(new Water(), 11, 6);
        this.add(new Water(), 7, 6);
    }
}
