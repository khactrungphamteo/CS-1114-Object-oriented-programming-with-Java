import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 *  a Jeroo that acts like a castle guard, patrolling around a
 *  "water" castle.
 *
 *  @author Lindah Kotut
 *  @version 2017.09.05
 */
public class PatrolJeroo extends Jeroo
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new PatrolJeroo object.
     */
    public PatrolJeroo()
    {
        super();
    }


    //~ Methods ...............................................................

    // ----------------------------------------------------------
    /**
     * March around the entire castle.
     */
    public void patrolCastle()
    {
        this.patrolWall();
        this.patrolWall();
        this.patrolWall();
        this.patrolWall();
    }


    // ----------------------------------------------------------
    /**
     * March along one wall.
     */
    public void patrolWall()
    {
        this.patrolStraight();
        this.patrolCorner();
    }
        
        
    // ----------------------------------------------------------
    /**
     * March along the straight part of the wall.
     */
    public void patrolStraight()
    {
        this.hop();
        this.hop();
    }


    // ----------------------------------------------------------
    /**
     * March around the corner.
     */
    public void patrolCorner()
    {
        this.hop();
        this.turn(LEFT);
        this.hop();
    }
}









