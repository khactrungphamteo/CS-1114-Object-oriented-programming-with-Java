import sofia.micro.jeroo.*;

//-------------------------------------------------------------------------
/**
 *  A smarter castle guard jeroo that knows how to navigate
 *  turret-style corners.
 *
 *  @author Lindah Kotut
 *  @version 2017.09.05
 */
public class TurretJeroo extends PatrolJeroo
{
    //~ Fields ................................................................



    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new TurretJeroo object.
     */
    public TurretJeroo()
    {
        super();
    }


    //~ Methods ...............................................................

    // ----------------------------------------------------------
    /**
     * March around the corner.
     */
    public void patrolCorner()
    {

    }
}
