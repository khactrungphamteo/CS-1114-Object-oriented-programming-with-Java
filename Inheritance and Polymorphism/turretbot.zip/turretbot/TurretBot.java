import sofia.micro.lightbot.*;

public class TurretBot extends PatrolBot
{
    public TurretBot()
    {
        // nothing special to initialize
    }

    public void turnCorner()
    {
        this.turnLeft();
        super.turnCorner();
        super.turnCorner();
        super.turnCorner();
        this.turnLeft();
    }
}
