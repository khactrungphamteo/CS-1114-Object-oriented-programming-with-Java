import sofia.micro.lightbot.*;

public class PatrolBot extends LightBot
{
    public PatrolBot()
    {
        // no initialization needed here
    }
    

    public void patrolCastle()
    {
        this.walkOneWall();
        this.walkOneWall();
        this.walkOneWall();
        this.walkOneWall();
    }
    
    public void walkOneWall()
    {
        this.move();
        this.move();
        this.turnCorner();
    }
        
    public void turnCorner()
    {
        super.move();
        this.turnRight();
        this.move();
    }
}
