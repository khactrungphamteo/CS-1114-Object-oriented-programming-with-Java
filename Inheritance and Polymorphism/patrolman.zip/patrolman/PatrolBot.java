import sofia.micro.lightbot.*;

public class PatrolBot extends LightBot
{
    public PatrolBot()
    {
        // no initialization needed here
    }
    

    public void patrolCastle()
    {
        
    }
    
    public void walkOneWall()
    {
        this.move();
        this.move();
        this.move();
        this.move();
        this.turnRight();
    }
}
