import sofia.micro.lightbot.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class Castle extends Level
{
    //~ Fields ................................................................


    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Castle object.
     */
    public Castle()
    {
        // Nothing to initialize, leaving the world a default size

        prepare();
    }

    //~ Methods ...............................................................

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        sofia.micro.lightbot.Block block = new sofia.micro.lightbot.Block();
        this.add(block, 1, 2);
        sofia.micro.lightbot.Block block2 = new sofia.micro.lightbot.Block();
        this.add(block2, 2, 2);
        sofia.micro.lightbot.Block block3 = new sofia.micro.lightbot.Block();
        this.add(block3, 3, 2);
        sofia.micro.lightbot.Block block4 = new sofia.micro.lightbot.Block();
        this.add(block4, 3, 3);
        sofia.micro.lightbot.Block block5 = new sofia.micro.lightbot.Block();
        this.add(block5, 3, 4);
        sofia.micro.lightbot.Block block6 = new sofia.micro.lightbot.Block();
        this.add(block6, 2, 4);
        sofia.micro.lightbot.Block block7 = new sofia.micro.lightbot.Block();
        this.add(block7, 2, 4);
        sofia.micro.lightbot.Block block8 = new sofia.micro.lightbot.Block();
        this.add(block8, 1, 4);
        sofia.micro.lightbot.Block block9 = new sofia.micro.lightbot.Block();
        this.add(block9, 1, 3);
        block7.remove();
        PatrolBot patrolbot = new PatrolBot();
        this.add(patrolbot, 0, 1);
    }
}
